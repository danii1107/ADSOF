/**
 * RegistrationState
 * @author EPS
 */
package registrations;

public enum RegistrationState{
	STARTED, FILLED, VALIDATED, PAYED, FINISHED, REJECTED;
}